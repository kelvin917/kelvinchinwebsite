import { useNavigate } from 'react-router-dom';
import { User, Folder, Music, Mail } from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="w-full h-screen bg-gradient-to-b from-[#0f1a2a] to-[#1e2f47] flex items-center justify-center">
      <div className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-2xl p-8 text-center shadow-lg max-w-md mx-auto">
        <img
          src="/images/kelvin-dragon-logo-2.png"
          alt="Kelvin Logo"
          className="w-24 h-24 mx-auto mb-4 rounded"
        />
        <h1 className="text-3xl font-bold text-white mb-4">Kelvin Chin</h1>
        <p className="text-gray-300 mb-6">Web Learner · Piano Improviser · 觉醒中的都市修行者</p>

        <div className="flex justify-center gap-4 flex-wrap">
          <IconButton icon={<User size={20} />} label="About" onClick={() => navigate('/about')} />
          <IconButton icon={<Folder size={20} />} label="Projects" onClick={() => navigate('/projects')} />
          <IconButton icon={<Music size={20} />} label="Music" onClick={() => navigate('/music')} />
          <IconButton icon={<Mail size={20} />} label="Contact" onClick={() => navigate('/contact')} />
        </div>
      </div>
    </div>
  );
}

function IconButton({ icon, label, onClick }) {
  return (
    <button onClick={onClick} className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition duration-300">
      {icon}
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}