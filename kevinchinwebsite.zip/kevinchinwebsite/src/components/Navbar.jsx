import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 w-full bg-[#0f1a2a]/80 backdrop-blur-md text-white z-50 shadow-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition">
          <img
            src="/images/kelvin-dragon-logo-2.png"
            alt="Logo"
            className="w-8 h-8 rounded"
          />
        </Link>
        <div className="space-x-4">
          <Link to="/about" className="hover:text-cyan-300 transition">About</Link>
          <Link to="/projects" className="hover:text-cyan-300 transition">Projects</Link>
          <Link to="/music" className="hover:text-cyan-300 transition">Music</Link>
          <Link to="/contact" className="hover:text-cyan-300 transition">Contact</Link>
        </div>
      </div>
    </nav>
  );
}