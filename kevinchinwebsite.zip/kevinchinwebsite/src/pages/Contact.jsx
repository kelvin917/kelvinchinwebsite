export default function Contact() {
  return (
    <div className="min-h-screen bg-[#0f1a2a] text-white flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">Contact Me</h1>
      <p className="max-w-xl text-center text-gray-300">你可以通过 Email / IG / GitHub 等方式找到我，未来我会在这页放上社交方式和表单。</p>
    </div>
  );
}
