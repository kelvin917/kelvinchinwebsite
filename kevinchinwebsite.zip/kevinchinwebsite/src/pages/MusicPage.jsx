// src/pages/MusicPage.jsx
import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

function MusicPage() {
  const [songs, setSongs] = useState([]);
  const [currentSong, setCurrentSong] = useState(null);

  useEffect(() => {
    fetchSongs();
  }, []);

  async function fetchSongs() {
    const { data, error } = await supabase.from("songs").select("*");
    if (error) {
      console.error("Error fetching songs:", error);
    } else {
      setSongs(data);
    }
  }

  return (
    <div className="text-white p-4">
      <h1 className="text-2xl font-bold mb-4">🎵 Kelvin 音乐空间</h1>
      <ul className="mb-4">
        {songs.map((song) => (
          <li
            key={song.id}
            className="cursor-pointer hover:underline"
            onClick={() => setCurrentSong(song)}
          >
            {song.title}
          </li>
        ))}
      </ul>

      {currentSong && (
        <div>
          <h2 className="text-xl font-semibold">{currentSong.title}</h2>
          <audio controls className="mt-2 w-full">
            <source src={currentSong.url} type="audio/mpeg" />
            你的浏览器不支持 audio 播放。
          </audio>
        </div>
      )}
    </div>
  );
}

export default MusicPage;
