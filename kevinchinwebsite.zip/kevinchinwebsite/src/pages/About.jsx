export default function About() {
  return (
    <div className="min-h-screen bg-[#0f1a2a] text-white flex flex-col items-center justify-start p-6 pt-32">
      <h1 className="text-4xl font-bold mb-6">About Me</h1>

      <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-8 w-full max-w-md text-center shadow-md">
        <img
          src="/images/kelvin-dragon-logo-2.png"
          alt="Kelvin ID"
          className="w-24 h-24 mx-auto mb-4 rounded-full border border-white/20"
        />
        <h2 className="text-2xl font-semibold">Kelvin Chin</h2>
        <p className="text-gray-300">都市修行者 · 编码学徒 · 自由探索者</p>
      </div>

      <p className="text-gray-300 mb-4 max-w-xl text-center">
        我是 Kelvin，一位生活在城市边缘的修行者。白天在咖啡与忙碌中穿梭，晚上在代码与琴键间沉淀自己。
      </p>

      <p className="text-gray-300 mb-4 max-w-xl text-center">
        我没有完美的起点，也不是科班出身的工程师。但我相信，通过持续修炼与觉察，可以从零构建一个自由又真实的人生系统。
      </p>

      <div className="mt-6 w-full max-w-md">
        <h2 className="text-xl font-semibold text-white mb-2">🧠 技术修炼技能树</h2>
        <ul className="list-disc list-inside text-gray-300 space-y-1">
          <li>Frontend：React, Tailwind CSS</li>
          <li>兴趣：网页开发、系统构建、个人网页优化</li>
        </ul>
      </div>

      <div className="mt-6 w-full max-w-md">
        <h2 className="text-xl font-semibold text-white mb-2">🎵 灵魂通道</h2>
        <ul className="list-disc list-inside text-gray-300 space-y-1">
          <li>钢琴即兴演奏 · 深夜旋律创作</li>
          <li>音乐是我与自己对话的方式</li>
        </ul>
      </div>

      <div className="mt-6 w-full max-w-md">
        <h2 className="text-xl font-semibold text-white mb-2">📍 现实副本履历</h2>
        <ul className="list-disc list-inside text-gray-300 space-y-1">
          <li>2024 – Now：Koufu 管理岗位（人流调度 / 咖啡冲泡 / 店务处理）</li>
          <li>2023 – 自学前端开发 & 系统构建</li>
          <li>2025 – 构建觉醒系统、技能地图、自我品牌</li>
        </ul>
      </div>

      <p className="text-sm text-gray-500 text-center mt-12 italic">
        「不是为他人而活，而是为了成为真正的自己。」
      </p>
    </div>
  );
}