import { useRef } from 'react';

export default function Music() {
  const musicList = [
    {
      title: "Kelvin - Piano Track 1",
      src: "/audio/kelvin-piano-1.m4a"
    },
    {
      title: "Kelvin - Piano Track 2",
      src: "/audio/kelvin-piano-2.m4a"
    },
    {
      title: "Kelvin - Piano Track 3",
      src: "/audio/kelvin-piano-3.m4a"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0f1a2a] text-white flex flex-col items-center justify-start p-6 pt-32">
      <h1 className="text-4xl font-bold mb-4">My Music</h1>
      <p className="max-w-xl text-center text-gray-300 mb-6">我平时喜欢即兴弹奏，有空会分享一些旋律或钢琴片段在这里。</p>

      <div className="w-full max-w-md space-y-8">
        {musicList.map((track, index) => {
          const audioRef = useRef(null);

          const handlePlay = () => {
            if (audioRef.current) {
              audioRef.current.play();
            }
          };

          return (
            <div key={index} className="w-full flex flex-col items-center">
              <img
                src="/images/kelvin-dragon-logo-1.png"
                alt="Album Cover"
                className="w-32 h-32 rounded mb-2 border border-white/10 shadow cursor-pointer hover:opacity-80 transition"
                onClick={handlePlay}
              />
              <audio ref={audioRef} controls className="w-full rounded-lg">
                <source src={track.src} type="audio/mp4" />
                Your browser does not support the audio element.
              </audio>
              <p className="text-sm text-gray-400 text-center mt-2">🎵 {track.title}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}