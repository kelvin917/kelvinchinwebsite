export default function Projects() {
  return (
    <div className="min-h-screen bg-[#0f1a2a] text-white flex flex-col items-center justify-center p-6">
      <h1 className="text-4xl font-bold mb-4">Projects</h1>
      <p className="max-w-xl text-center text-gray-300">这里将展示我完成或正在开发的网页、App、小作品等内容。</p>
    </div>
  );
}
